var sueldobase = 1400000
var comision = 0
var totalpago = 0

var ventas =parseFloat(prompt("Ingrese la cantidad de ventas en millones de pesos:"))

if (ventas >= 1000000 && ventas <= 30000000) {
    comision = ventas*(5/100)
} else if (ventas >= 31000000 && ventas <= 50000000) {
    comision = ventas *(15/100)
} else if (ventas > 50000000) {
    comision = ventas *(20/100)
}

totalpago = sueldobase + comision

console.log("El salario básico es: " + sueldobase);
console.log("La comisión ganada es: " + comision);
console.log("El salario total del empleado es: " + totalpago);